import pickle
import cv2
import os

def resize_and_save_features(image_path, target_size=(64, 64)):
  """
  Resizes an image, extracts features (grayscale pixels), and returns them as a list.

  Args:
      image_path: Path to the image file.
      target_size: Target size for resizing the image (optional).

  Returns:
      A flattened list of grayscale pixel values from the resized image, or None if there's an error.
  """
  try:
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is not None:
      resized_image = cv2.resize(image, target_size)
      features = resized_image.flatten().tolist()
      return features
    else:
      print(f"Error loading image: {image_path}")
      return None
  except Exception as e:
    print(f"Error processing image {image_path}: {e}")
    return None

# Specify the folder containing your images
image_folder = "C:\\Users\\mayan\\Desktop\\Project\\Project two\\test1"

# Create an empty list to store features
test = []

# Loop through all image files in the folder
for filename in os.listdir(image_folder):
  # Get the full path of the image
  image_path = os.path.join(image_folder, filename)

  # Check if it's a valid image file (modify extensions as needed)
  if filename.lower().endswith((".jpg", ".jpeg", ".png")):
    features = resize_and_save_features(image_path)
    if features:
      test.append(features)

# Save the features list to a pickle file
with open("test.pickle", "wb") as f:
  pickle.dump(test, f)

print(f"Pickled image features saved to test.pickle")